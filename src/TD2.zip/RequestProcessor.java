import java.net.Socket;

public class RequestProcessor {
    private void process(){}
    public RequestProcessor(Socket socket) {
    }
}
