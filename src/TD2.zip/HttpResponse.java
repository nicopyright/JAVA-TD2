import java.io.BufferedWriter;
import java.net.Socket;

public class HttpResponse {
    private BufferedWriter output;
    public HttpResponse(Socket socket) {

    }
    public void ok(String message){

    }
    public void notFound(String message){

    }

}
